function newI = lm_imdilate(I,numPix)
% USAGE: newI = lm_imdilate(I,numPix)
% dilation morphological operator
% I is a binary image
% numPix is the number of 1 pixel in a 3 by 3 neighborhood necessary for
% dilation

if max(I(:)) > 1 | min(I(:)) < 0
    error('input image must be binary');
end

% mask to pad the diagonal
F = [0 1 0; 1 0 1; 0 0 0];
N = conv2(I,F,'same');
newI = min(1,double(N>=numPix)+I);
