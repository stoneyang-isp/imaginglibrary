function [newI, fac] = compute_downSampleFac(I)
% USAGE: [newI, fac] = compute_downSampleFac(I)
% compute the down-sample factor that will be applied on the mask
% INPUT
%        I: input image
% OUTPUT
%        newI: new image in case the size was changed
%        fac: down-sample factor
% copyright laurence meylan - jan 05

newI = I;
[n m d] = size(newI);

% maximum size for input image
maxSIZE = 2048; 

% mask resolution
lowSIZE = 200; 

% down-sample input image if too big
while max(n,m) > maxSIZE
    disp('Warning: Image is too big, size is divided by 2');
    newI = imresize(newI,0.5);
    [n m d] = size(newI);
end

fac = max(n,m)/lowSIZE;