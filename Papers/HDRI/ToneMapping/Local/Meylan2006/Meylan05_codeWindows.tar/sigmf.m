function y = sigmf(x, b)
[m,n] = size(x);
z = m:n;
for i = 1:m
 for j=1:n   
  z(i,j) = (1/(1 + exp(-b(1) * (x(i,j) - b(2)))));    
 end;
end;
y = z;