% example of how to call runIterPCA

clear all;
close all;

path(path,'/home/lmeylan/Hdr_Raw_images/hdrImages');
path(path,'../../../../../DATA/');

%filename = 'On.hdr'
%ImF = read_rle_rgbe(filename);    
%newI = runIterPCA(ImF, filename);

filename = 'lausStairs.hdr'
ImF = read_rle_rgbe(filename);    
newI = runIterPCA(ImF, filename);

