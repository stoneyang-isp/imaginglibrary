#include "mex.h"
#include "math.h"

/* ************************************************************ */

/* this is a mex funcion that computes the mask 
   for a a given input image and an edge map. 
   sigmas are also given as parameters*/

/* It can be called in Matlab using
   out=runIterRetinex(im, e, sigIn, sigOut) */

/* the mask is a low-pass edge-preserving version 
   of the input image */

/* copyright laurence meylan - jan 05 */

/* ************************************************************ */

/* prototypes */
void runIterRetinex(double *, double *, double *);

/* Input Arguments */
#define	X1_IN	prhs[0]
#define	X2_IN	prhs[1]

#define	X3_IN	prhs[2]
#define	X4_IN	prhs[3]


/* Output Arguments */
#define	Y1_OUT	plhs[0]

/*I decided not to use dynamic arrays. So we need to 
  fix a maximum size for input image */
#define	maxSize 1000


#define PI 3.14159265358979
/* ************************************************************ */

double sigmaIn  = 0;
double sigmaOut = 0;

double sigmaCurrent = 0;
double threshDistance = 0; /* size of the filter  3*sigma evtl put 4 */

int ImRow;
int ImCol;

/* sumW = sum of coefficient for each pixel depending on edge maps and borders */
double sumW;


/* contain the input image */
double daImage[maxSize][maxSize];

/* contain the edge map */
int iaEdgeImage[maxSize][maxSize];

/* contain the extended edge map for each pixel */
int iaEdgeTemp[maxSize][maxSize];

/* contain the mask */
double arMask[maxSize][maxSize] ;

double maskVal;
/* ************************************************************ */

/* this function returns 1 if there is an edge at pixel i,j or before the pixel */
bool isAnEdge(int i, int j, int iCounter) {
  /* iCounter is incremented for each pixel, trick */
  return (((int)iaEdgeImage[i][j] > 100) | ((int)iaEdgeTemp[i][j] == iCounter));
}

/* compute the gaussian value for distance d and sigma s */
double gaussDist(double d, double s) {
  return exp(-pow(d,2)/pow(2*s,2));
}

/* ************************************************************ */
/* this function computes the weighted sum of neighboring pixel for pixel r,c. 
   The surround is covered radially (center to radius) using 4 directions 
   (east, west, north, south) 

   When an edge is met, sigma used to compute the weight changes and the edge 
   effect is propagated in the radial direction. We use a counter to check if 
   a pixel is behind an edge or not so we don't have to reset the value of 
   iaEdgeTemp for each pixel.

   The function looks complicated but in fact it's 4 times the same 
   procedure, one for each direction */

/* ************************************************************ */
double iterCompute(int r,int c, int counter) {

  double maskSum = 0; /* contains the sum of coefficients */
  int N = threshDistance; /* the radius of the filter size */

  int rowJj = 0; /* height */
  int colI = 0;  /* width */
  int colIi = 0; /* width */
  int diag = 0;

  int colX = 0;
  int rowY = 0;
  double w = 0; /* temp weight */
  int rowJ = 0;

  /* ----------------------------------------------------------------------------------*/
  /* right quadrant */
  sigmaCurrent = sigmaIn;
  rowJ = 0;  /* height*/

  /* go from the center to the right extremity of the surround*/
  for (colI=0; colI<N+1; colI++) {

    /* coordinate in the image */
    colX = c+colI;
    rowY = r+rowJ;

    /* check if inside the image */
    if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
      /* check if it's an edge or if located after an edge on the radial direction */
      if (isAnEdge(rowY, colX, counter))	{
	sigmaCurrent = sigmaOut;
	/* iaEdgeTemp[rowY+1][colX] = counter;  toward the top */
	iaEdgeTemp[rowY][colX+1] = counter; /* toward the right */
	/* iaEdgeTemp[rowY-1][colX] = counter;  toward the bottom */
      }
      w = gaussDist(sqrt(pow(colI,2)+pow(rowJ,2)),sigmaCurrent);
      maskSum  = maskSum + daImage[rowY][colX]*w;
      sumW = sumW + w;
      /* debug */ 
      /* arMask[rowY][colX] = w;*/

      /* go along diagonal direction, toward the bottom */
      for (diag = colI+1; diag <N+1; diag++) {
	rowJj = diag-colI; 

	/* image coordinate */
	colX = c+diag;      
	rowY = r+rowJj;     

	/* check if inside the image */
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if (isAnEdge(rowY,colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    /* check if next pixels are inside the image */
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)) {
	      iaEdgeTemp[rowY][colX+1] = counter; /* to the right  */
	      /* iaEdgeTemp[rowY+1][colX+1] = counter; */
	    }
	  }
	  w = gaussDist(sqrt(pow(diag,2)+pow(rowJj,2)),sigmaCurrent);
	  maskSum = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /* debug */ 
	  /* arMask[rowY][colX] = w; */
	}
      }
      /* reset to initial value when one radial direction is finished */
      sigmaCurrent = sigmaIn;
    
      /* go along diagonal direction, to the top */
      for (diag = colI+1; diag <N+1; diag++) {
	rowJj = -(diag-colI); 

	/* image coordinate */
	colX = c+ diag; 
	rowY = r+ rowJj;

	/* check if inside the image */
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if (isAnEdge(rowY, colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    /* check if next pixels are inside the image */
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)){
	      iaEdgeTemp[rowY][colX+1] = counter;  /* to the right*/
	      /* iaEdgeTemp[rowY-1][colX+1] = counter; */
	    }
	  }
	  w = gaussDist(sqrt(pow(diag,2)+pow(rowJj,2)),sigmaCurrent);
	  maskSum = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /* debug */ 
	  /* arMask[rowY][colX] = w ;*/
	}
      }
      sigmaCurrent = sigmaIn;
    }
  }

  /* ----------------------------------------------------------------------------------*/
  /* same procedure for left quadrant*/
  sigmaCurrent = sigmaIn;
  rowJ = 0; /* height */
  /* go from the center to the left extremity of the surround */
  for (colI = 0;colI >-N-1; colI--) {
    colX = c + colI;
    rowY = r + rowJ;
    if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
      if  (isAnEdge(rowY,colX, counter)) {
	sigmaCurrent = sigmaOut;
	/*iaEdgeTemp[rowY+1][colX] = counter; to the top */
	iaEdgeTemp[rowY][colX-1] = counter;  /* to the left */
	/*iaEdgeTemp[rowY-1][colX] = counter; to the bottom */
      }
      w = gaussDist(sqrt(pow(colI,2)+pow(rowJ,2)),sigmaCurrent);
      maskSum = maskSum + daImage[rowY][colX]*w;
      sumW = sumW + w;
      /* debug */ 
      /* arMask[rowY][colX] = w;*/

      /* go along diagonal direction toward the bottom */
      for (diag = colI-1; diag > -N-1; diag--) {
	rowJj = -(diag-colI);        
	colX = c+ diag;
	rowY = r+rowJj;
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if  (isAnEdge(rowY, colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)) {
	      iaEdgeTemp[rowY][colX-1] = counter;   /* to the left */
	      /* iaEdgeTemp[rowY+1][colX-1] = counter; */
	    }
	  }
	  w = gaussDist(sqrt(pow(diag,2)+pow(rowJj,2)),sigmaCurrent);
	  maskSum = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /* debug */ 
	  /* arMask[rowY][colX] = w;*/
	}
      }
      sigmaCurrent = sigmaIn;

      /* go along diagonal direction toward the top */
      for (diag = colI-1; diag > -N-1; diag--) {
	rowJj = diag-colI; 
	colX = c+diag;
	rowY = r+rowJj;
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if  (isAnEdge(rowY, colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)) {
	      iaEdgeTemp[rowY][colX-1] = counter; /* to the left */
	      /* iaEdgeTemp[rowY-1][colX-1] = counter; */
	    }
	  }
	  w = gaussDist(sqrt(pow(diag,2)+pow(rowJj,2)),sigmaCurrent);
	  maskSum = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /*debug*/ 
	  /* arMask[rowY][colX] = w;*/
	}
      }
      sigmaCurrent = sigmaIn;
    }
  }


  /* ----------------------------------------------------------------------------------*/
  /* same procedure for top quadrant*/ 
  sigmaCurrent = sigmaIn;
  colI = 0; 

  /* go from the center to the top extremity of the surround */
  for (rowJ = -1; rowJ > -N-1; rowJ--) { 
    colX = c+colI;
    rowY = r+rowJ;
    if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
      if  (isAnEdge(rowY, colX, counter)) {
	sigmaCurrent = sigmaOut;
	/* iaEdgeTemp[rowY][colX-1] = counter; to the left */
	iaEdgeTemp[rowY-1][colX] = counter; /* to the top */
	/* iaEdgeTemp[rowY][colX+1] = counter; to the right */
      }
      w = gaussDist(sqrt(pow(colI,2)+pow(rowJ,2)),sigmaCurrent);
      maskSum = maskSum + daImage[rowY][colX]*w;
      sumW = sumW + w;
      /*debug*/ 
      /* arMask[rowY][colX] = w;*/

      /* go along diagonal direction toward the left */
      for (diag = rowJ-1;diag>-N-1;diag--) {
	colIi = diag-rowJ; 
	colX = c+colIi;
	rowY = r+diag; 
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if  (isAnEdge(rowY, colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)) {
	      iaEdgeTemp[rowY-1][colX] = counter; /* to the top */
	      /* iaEdgeTemp[rowY-1][colX+1] = counter; */
	    }
	  }
	  w = gaussDist(sqrt(pow(diag,2)+pow(colIi,2)),sigmaCurrent);
	  maskSum  = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /*debug*/ 
	  /* arMask[rowY][colX] = w;*/
	}
      }
      sigmaCurrent = sigmaIn;
      /* go along diagonal direction toward the right */
      for (diag = rowJ-1;diag>-N-1;diag--) {
	colIi = -(diag-rowJ);
	colX = c+colIi;
	rowY = r+diag;
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if  (isAnEdge(rowY, colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)) {
	      iaEdgeTemp[rowY-1][colX] = counter;  /* to the top */
	      /* iaEdgeTemp[rowY-1][colX-1] = counter;  */
	    }
	  }
	  w = gaussDist(sqrt(pow(diag,2)+pow(colIi,2)),sigmaCurrent);
	  maskSum = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /*debug*/ 
	  /* arMask[rowY][colX] = w;*/
	}
      }
      sigmaCurrent = sigmaIn;
    }
  }

  /* ----------------------------------------------------------------------------------*/
  /* same procedure for bottom quadrant*/ 
  sigmaCurrent = sigmaIn;
  colI = 0; 

  /* go from the center to the top extremity of the surround */
  for (rowJ = 1; rowJ < N+1;rowJ++) {
    colX = c+colI;
    rowY = r+rowJ;
    if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
      if  (isAnEdge(rowY, colX, counter)) {
	sigmaCurrent = sigmaOut;
	/* iaEdgeTemp[rowY][colX-1] = counter; to the left */
	/* iaEdgeTemp[rowY][colX+1] = counter; to the right */
	iaEdgeTemp[rowY+1][colX] = counter;
      }
      w = gaussDist(sqrt(pow(colI,2)+pow(rowJ,2)),sigmaCurrent);
      maskSum = maskSum + daImage[rowY][colX]*w;
      sumW = sumW + w;
      /*debug*/ 
      /* arMask[rowY][colX] = w;*/

      /* go along diagonal direction toward the left */
      for (diag = rowJ+1;diag <N+1; diag++) {
	colIi = -(diag-rowJ);
	colX = c+colIi;
	rowY = r+diag;
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if  (isAnEdge(rowY, colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)) {
	      iaEdgeTemp[rowY+1][colX] = counter; /* to the bottom */
	      /* iaEdgeTemp[rowY+1][colX+1] = counter; */
	    }
	  }
	  w = gaussDist( sqrt(pow(diag,2)+pow(colIi,2)),sigmaCurrent);
	  maskSum = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /*debug*/ 
	  /* arMask[rowY][colX] = w;*/
	}
      }
      sigmaCurrent = sigmaIn;
          /* go along diagonal direction toward the right */
      for (diag = rowJ+1; diag < N+1; diag++) {
	colIi = diag-rowJ;
	colX = c+colIi;
	rowY = r+diag;
	if (colX < ImCol && rowY < ImRow && colX >= 0 && rowY >= 0) {
	  if  (isAnEdge(rowY, colX, counter)) {
	    sigmaCurrent = sigmaOut;
	    if (colX > 0 & rowY > 0 & colX < (ImCol-1) & rowY < (ImRow-1)) {
	      iaEdgeTemp[rowY+1][colX] = counter; /* to the top */
	      /* iaEdgeTemp[rowY+1][colX-1] = counter; */
	    }
	  }
	  w = gaussDist(sqrt(pow(diag,2)+pow(colIi,2)),sigmaCurrent);
	  maskSum = maskSum + daImage[rowY][colX]*w;
	  sumW = sumW + w;
	  /*debug*/ 
	  /* arMask[rowY][colX] = w;*/
	}
      }
      sigmaCurrent = sigmaIn;
    }
  }
  return maskSum;
}

/* ************************************************************ */
/* mex function, does the transfer between matlab and C
/* ************************************************************ */
void mexFunction(
		 int nlhs, mxArray *plhs[],
		 int nrhs, const mxArray *prhs[])     
{
  
  /* pointer to the input variables */
  double	*x1_in, *x2_in, *x3_in, *x4_in;
  
  /* pointer to the output variables */
  double	*y1_out;

  /* Check for proper number of arguments */
  if (nrhs != 4) mexErrMsgTxt("Four input arguments.");
  if (nlhs > 1) mexErrMsgTxt("One output argument.");
  

  /* dimension of the image, has to be a double */
  ImRow = mxGetM(X1_IN);
  ImCol = mxGetN(X1_IN);


  if ( !mxIsNumeric(X1_IN) || 
       mxIsComplex(X1_IN) || 
       mxIsSparse(X1_IN)  || 
       !mxIsDouble(X1_IN) ) mexErrMsgTxt("Error in x1.");
  
  if ( !mxIsNumeric(X2_IN) || 
       mxIsComplex(X2_IN) || 
       mxIsSparse(X2_IN)  || 
       !mxIsDouble(X2_IN) ) mexErrMsgTxt("Error in x2.");

  if ( !mxIsNumeric(X3_IN) || 
       mxIsComplex(X3_IN) || 
       mxIsSparse(X3_IN)  || 
       !mxIsDouble(X3_IN) ) mexErrMsgTxt("Error in x3.");


  if ( !mxIsNumeric(X4_IN) || 
       mxIsComplex(X4_IN) || 
       mxIsSparse(X4_IN)  || 
       !mxIsDouble(X4_IN) ) mexErrMsgTxt("Error in x4.");

  x1_in = mxGetPr(X1_IN);
  x2_in = mxGetPr(X2_IN);

  x3_in = mxGetPr(X3_IN);
  x4_in = mxGetPr(X4_IN);

  sigmaIn  = *x3_in;
  sigmaOut = *x4_in;
  sigmaCurrent = sigmaIn;

  /* I could use 3 here */
  threshDistance = (int)3*sigmaIn+1;

  if (ImRow >  maxSize ||  ImCol > maxSize) mexErrMsgTxt("Mask size is too big");
  
  /*mexPrintf(" sigmaIn: %f, sigmaOut: %f, threshDistance: %f \n", sigmaIn, sigmaOut, threshDistance);*/


  Y1_OUT = mxCreateDoubleMatrix(ImRow,ImCol, mxREAL);   
  y1_out = mxGetPr(Y1_OUT);	
  
  /* Function to be executed */
  runIterRetinex(x1_in,y1_out,x2_in);
}

/* ************************************************************ */
/* This function calls iterCompute on each pixel
                 takes care of vector to matrix transformation
*/
/* ************************************************************ */
void runIterRetinex(double * x, double * y, double *e)
{ 
  
  int totSize = ImRow*ImCol; /*total size of pixel in image*/


  int tt; 
  int i;
  int j;
  int r;
  int c;

  int count = 0;

  /* put values of edgeImage and luminance image into C array */
  for (tt=0;tt<totSize;tt++) {
    daImage[(int)fmod(tt,ImRow)][(int)floor((double)tt/(double)ImRow)] = x[tt];
    iaEdgeImage[(int)fmod(tt,ImRow)][(int)floor((double)tt/(double)ImRow)] = (int)e[tt];
  }

  /* initialise tempEdgeImage with counter = -1*/
  for (i=0;i<ImRow;i++) {
    for (j=0;j<ImCol;j++) {
      iaEdgeTemp[i][j] = -1;  
    }
  }

  /* treat image pixel after pixel */
  for (i=0;i<ImRow;i++) {
    for (j=0;j<ImCol;j++) {

      sumW = 0; /* sum of coefficients for one  pixel */
      maskVal = iterCompute(i,j,count); /* mask value at pixel i j*/
      count++; /* increment count (trick to propagate edges) */
      arMask[i][j] = maskVal/sumW; /* normalize by pixel sum of coefficient */
    }
  }

  /* store mask in output variable */
  for (r = 0;r<ImRow;r++) {
    for (c = 0;c<ImCol;c++) {
      y[c*ImRow+r] = arMask[r][c];
    }
  }
}
