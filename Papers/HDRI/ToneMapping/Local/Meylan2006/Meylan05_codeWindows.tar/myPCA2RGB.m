function RGB = myPCA2RGB(PCA, V)
% USAGE: RGB = myPCA2RGB(PCA, V)
% this function returns the RGB value after the inverse PCA transformation 
% INPUT
%        PCA: principal components
%        V:   eigen values [v1 v2 v2]
% OUTPUT
%        RGB: RGB image
% copyright laurence meylan - jan 05

[rS cS d] = size(PCA);

% change matrix represenation into vector representation
b1 = PCA(:,:,1);
b2 = PCA(:,:,2);
b3 = PCA(:,:,3);
b_vec = cat(2,b1(:),b2(:),b3(:));

% apply transformation
RGB_vec = b_vec*inv(V);

% change from vector representation to matrix
R = reshape(RGB_vec(:,1),rS,cS);
G = reshape(RGB_vec(:,2),rS,cS);
B = reshape(RGB_vec(:,3),rS,cS);
RGB = cat(3,R,G,B);