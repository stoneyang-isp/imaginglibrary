function E = edgeImage(I)
% USAGE: E = edgeImage(I)
% Compute the edge map for the mask computation
% INPUT
%        I: grayscale image, mask resolution
% OUTPUT
%        E: edge map
% copyright laurence meylan - jan 05

% canny edge detector
E = edge(I,'canny',0.2);

% add a dilation step to avoid that edge pixel be missed on diagonals
E = lm_imdilate(double(E),2);
