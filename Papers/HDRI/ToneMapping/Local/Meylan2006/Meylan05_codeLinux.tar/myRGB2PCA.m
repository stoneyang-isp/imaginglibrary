function [PCA, V] = myRGB2PCA(RGB)
% USAGE [PCA V] = myRGB2PCA(RGB)
% return the principal component data and the eigen values
% INPUT
%        RGB: rgb image
% OUTPUT
%        PCA: three principal compoenent
%        V  : eigen values [v1 v2 v3]
% copyright laurence meylan - jan 05

% from matrix representation to vector
r = RGB(:,:,1); 
g = RGB(:,:,2);
b = RGB(:,:,3);
[rS cS d] = size(RGB);
rVec = r(:);
gVec = g(:);
bVec = b(:);
Ivec = cat(2,rVec,gVec,bVec);

% compute eigen vector
[eigenVec score eigenVal ts] = princomp(Ivec);
% the luminance is normalized to 1
V = eigenVec/(sum(eigenVec(:,1)));

% transformation from RGB to PCA representation
Bvec = Ivec*V;

% from vector representation to matrix
b1_mat = reshape(Bvec(:,1),rS,cS);
b2_mat = reshape(Bvec(:,2),rS,cS);
b3_mat = reshape(Bvec(:,3),rS,cS);
PCA = cat(3,b1_mat, b2_mat, b3_mat);