function newI = globalOpPow(I, opt)
% USAGE [newI = globalOpPow(I, opt)
% provides the first adaptation step
% INPUT
%        I: rgb image or grayscale image
%        opt: options for exponent computation
% OUTPUT
%        newI: globally corrected image
% copyright laurence meylan - jan 05

[r c d] = size(I);
if d == 1
    L_01 =  max(I,0.001);
elseif d == 3
    L_01 =  max(0.299*I(:,:,1)+0.587*I(:,:,2)+0.114*I(:,:,3),0.001);
else
    error('wrong image dimensions');
end

% computes log-average luminance
AL = sum(log(L_01(:)*100))/(length(L_01(:)));

% computes exponent depending on the option
if (opt == 'exp')
    powExp = exp(AL+2)/(exp(4)+(1/3))+(1/3);
elseif (opt == 'lin')
    powExp = (1/6)*AL+(2/3);
else
    error('wrong option')
end

% exponent can not be greated that 1 nor smaller than 1/3
powExp = min(max(powExp,0.33333),1);
newI = I.^powExp;