function y = scaleImage(x, minI, maxI)
% scale an image between minI and maxI
% does not take the 3 channels separately
% USAGE y = scaleImage(x, minI, maxI)
% INPUT     x: image
%            minI : minumim after scaling
%            maxI : maximum after scaling
% OUTPUT    y : scaled image
% copyright laurence meylan - jan 05

minX = min(x(:));
tmp = x - minX;

minTmp = min(tmp(:));
maxTmp = max(tmp(:));

if (maxTmp == 0)
    error('ERROR in scaleImage.m : divide by zero');
else
    y = (tmp*(maxI-minI)/maxTmp) + minI;
end
