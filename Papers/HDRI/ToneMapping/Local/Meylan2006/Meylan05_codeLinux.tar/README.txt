RETINEX BASED ADAPTIVE FILTER METHOD
software

author: laurence Meylan,
        laurence.meylan@epfl.ch
last changed Jan 2005
** ** **

Remark:

These files were developed with Maltab version 7 on Linux (fedora 3).
They use the matlab image processing toolbox and a mex function.

runIterRetinex.c needs to be compiled using mex compiler

main.m gives an example on how to run the program

** ** **
List of files:
main.m* 
compute_downSampleFac.m*  
globalOpPow.m*  
lm_imdilate.m  
myPCA2RGB.m*  
runIterPCA.m*      
scaleImage.m*
edgeImage.m*              
histoClip.m*    
myRGB2PCA.m*  
runIterRetinex.c*  
sigmFac.m*

author: laurence Meylan,
        laurence.meylan@epfl.ch
last changed Nov 2005
** ** **
Change output image from jpg to tiff
