function y = sigmFac(x,varargin)
% sigmoid function to weight the mask with a sigmoid function
% USAGE y = sigmFac(x,varargin)
% INPUT : x is in between 0 and 255
%         opt: a is the sigmoid slope factor; 10 is a good option
%         opt: c is the sigmoid position factor; 0.5 is a good option
% OUTPUT: y is in between 0 and 1
% copyright laurence meylan - jan 05

if min(x(:)) < 0 | max(x(:)) > 255
    error('ERROR: sigmFac: x must be between 0 and 255');
end

if max(size(varargin)) == 0
    a = 10;
    c = 0.5;
elseif max(size(varargin)) == 1
    a = varargin{1};
    c=0.5;
else 
    a = varargin{1};
    c = varargin{2};
end

y = scaleImage(abs(1-sigmf(x/255,[a c])),0,1);
