function new_image = runIterPCA(H_lin01, filename)
% take a floating point color image, extract luminance, treat luminance and
% recompose the color image with a saturation enhancement factor
% USAGE:   new_image = runIterPCA(H_lin01, filename)
% INPUT :  H_lin01: floating point hdr image
%          filename: file name to store results
% OUTPUT:  new_image: treated image
% copyright laurence meylan - jan 05

new_image = 0;

% sigmaOrig: adaptive filter intitial size
% sigmaAfterEdge: adaptive filter size after adaptation
sigmaOrig = 16;
sigmaAfterEdge = 5;
filename = [filename '16_5'];

%%%%%%
% 1: compute the down-sample factor
[H_lin01 fac] = compute_downSampleFac(H_lin01);
H_lin01 = H_lin01/max(H_lin01(:));
%%%%%%

%%%%%%
% 2: transform the image into a color space defined by PCA
[H_lin_CS01 V] = myRGB2PCA(H_lin01);
% take the luminance (first principal component)
H_Ylin01 = H_lin_CS01(:,:,1);
% re-scale in between 0 and 1 (sometimes the PCA operation causes the luminance
% to have values smaller than 1)
H_Ylin01 = H_Ylin01/max(H_Ylin01(:));

%%%%%%
% 3: apply first global adaptation (exponent 1 to 1/3)
H_Ylin01 = globalOpPow(H_Ylin01,'exp'); 

%%%%%%%% %%%%%%%%% low res %%%%%%% %%%%%%%%%%
% 4: compute the low resolution version of the image
L_Ylin01 = imresize(H_Ylin01, 1/fac, 'bilinear');
%%%%%% 

%%%%%% 
% 5: extract the edges
edgeI = edgeImage(L_Ylin01);
%%%%%% 

%%%%%% 
% 6: apply Retinex on the luminance
L_mask01 = runIterRetinex(L_Ylin01, double(edgeI)*255, sigmaOrig, sigmaAfterEdge);
%%%%%% 

%%%%%% 
% 7: resize the mask to high resolution size
[m n d] = size(H_lin01);
H_mask01 = imresize(L_mask01,[m n], 'bilinear');
%%%%%% 

%%%%%%
% 8: take the log of the image and the log of the mask
% I chose delta = 0.1 because it was a good trade-off. Indeed, a very small delta 
% increases the contrast too much in the dark area and delta = 1 does not 
% allow to recover details when the image is really dark.
% log(H_Ylin01) often has negative values while log(mask) rarely becomes
% negative due to its low-pass property.
H_Ylog01 =     log(max(0.1,H_Ylin01*100))/log(100);
H_logMask_01 = log(max(0.1,H_mask01*100))/log(100);
%%%%%% 

%%%%%% 
% 9:  retinex operation
% The image that serves for the sigmoid has to be in the range 0,1. 
% The sigmoid is compulsory to keep the white white and the black black.

sigm_iter_i10 =  scaleImage(H_Ylog01 - sigmFac(max(min(H_Ylog01,1),0)*255,10).*H_logMask_01,0,1);
% clipping to remove outliers
sigm_iter_i10_h =   histoClip(sigm_iter_i10, 0.01, 0.99);
newL = sigm_iter_i10_h;

% save grayscale image
s = [filename '_sigm10_h.tiff'];
imwrite(sigm_iter_i10_h, s, 'compression', 'none');

%%%%%% %%%%%%%%%% %%%%%%%%%% %%%%%%%%%%%% %%%%%%%%%%
% 10: color processing 

rgb1 = H_lin01; % change of variable

% global operation as for the luminance
rgb1 = globalOpPow(rgb1,'exp'); 

% take the logarithm but does not allow negative values
% makes a difference for images that have details  < 0.01
rgb1 = log(max(1,rgb1*100))/log(100);

% PCA transformation
[pca1 V1] = myRGB2PCA(rgb1);

% store the max and min of the luminance
max1 = max(max(pca1(:,:,1)));
min1 = min(min(pca1(:,:,1)));

% recompose the image
a = 1; % no saturation enhancement
new_pca1 = cat(3,scaleImage(newL,min1,max1), a*pca1(:,:,2), a*pca1(:,:,3));
new_rgb1 = myPCA2RGB(new_pca1,V1);

% store image
s = [filename '_sigm10_col_h.tiff'];
imwrite(histoClip(new_rgb1,0.01,0.99),s, 'compression', 'none')

a = 1.6254; % saturation enhancement
new_pca1 = cat(3,scaleImage(newL,min1,max1), a*pca1(:,:,2), a*pca1(:,:,3));
new_rgb1 = myPCA2RGB(new_pca1,V1);

% store image
s = [filename 'a2_sigm10_col_h.tiff'];
imwrite(histoClip(new_rgb1,0.01,0.99),s, 'compression', 'none')
