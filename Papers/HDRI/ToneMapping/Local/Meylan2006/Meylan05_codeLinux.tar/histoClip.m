function newI = histoClip(I, tMin, tMax)
% USAGE: newI = histoClip(I, tMin, tMax)
% Apply a histogram clipping and scaline
% INPUT
%        I: input image, can be grayscale or color
%        tMin, tMax: percentage for histogram clipping
%        example: 0.01, 0.99
% OUTPUT
%        newI: image clipped and scaled in the range [0 1]
% copyright laurence meylan - jan 05

% trick to make stretchlim work correctly
I = I/max(I(:));
% find low and high values
low_high = stretchlim(I, [tMin tMax]);
newMax = max(low_high(2,:));
newMin = min(low_high(1,:));

% clip and scale
newI = scaleImage(min(max(I,newMin),newMax),0,1);  

