% SCRIPT
% main_fig1_fig6
% this file was used to generate figure 1 and figure 6


%% -----------------------------------------------------------------------
% HDR CFA Image Rendering (Tone Mapping) 
% Written by David Alleysson and Laurence Meylan
% Copyright (C) 2007 Laboratory of Audiovisual Communications (LCAV), 
% Ecole Polytechnique Federale de Lausanne (EPFL), 
% CH-1015 Lausanne, Switzerland 
% 
% This program is free software; you can redistribute it and/or modify it 
% under the terms of the GNU General Public License as published by the 
% Free Software Foundation; either version 2 of the License, or (at your 
% option) any later version. This software is distributed in the hope that 
% it will be useful, but without any warranty; without even the implied 
% warranty of merchantability or fitness for a particular purpose. 
% See the GNU General Public License for more details 
% (enclosed in the file GPL). 
%
% Latest modifications: January 25, 2007, by Laurence Meylan


close all
clear all

global DISPLAY
DISPLAY = 1;

global FILTER_HORI
global FILTER_AMACRINE

FILTER_HORI = 3;
FILTER_AMACRINE = 1.5;


mainHDR_CFA('auto.hdr','HDR')

% here compute the linear RGB image and the gamma encoded image
I = read_rle_rgbe('auto.hdr');
I = I/max(I(:));
imwrite(I.^(1/2.2),['auto.hdr' '_rgb_gamma.jpg']);
imwrite(I,['auto.hdr' '_rgb_lin.jpg']);


