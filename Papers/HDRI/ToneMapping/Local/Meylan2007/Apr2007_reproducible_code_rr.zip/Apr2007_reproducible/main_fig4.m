% SCRIPT: this functios draws the graph of Figure 4

%% -----------------------------------------------------------------------
% HDR CFA Image Rendering (Tone Mapping) 
% Written by David Alleysson and Laurence Meylan
% Copyright (C) 2007 Laboratory of Audiovisual Communications (LCAV), 
% Ecole Polytechnique Federale de Lausanne (EPFL), 
% CH-1015 Lausanne, Switzerland 
% 
% This program is free software; you can redistribute it and/or modify it 
% under the terms of the GNU General Public License as published by the 
% Free Software Foundation; either version 2 of the License, or (at your 
% option) any later version. This software is distributed in the hope that 
% it will be useful, but without any warranty; without even the implied 
% warranty of merchantability or fitness for a particular purpose. 
% See the GNU General Public License for more details 
% (enclosed in the file GPL). 
%
% Latest modifications: January 25, 2007, by Laurence Meylan



function main

close all
clear all

X = 0:0.1:10;

hold on;

naka(X,1,'--');
naka(X,2,'-.');
naka(X,5,'.');
naka(X,10,'-');

legend('X0 = 1','X0 = 2','X0 = 5','X0 = 10')

function naka(X,X0,o)

y = X./(X+X0);

y = y/max(y(:));

plot(X,y,o,'linewidth',3);
