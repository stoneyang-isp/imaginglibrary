% SCRIPT
% call the function mainHDR_CFA for different types of images
% generate all results


%% -----------------------------------------------------------------------
% HDR CFA Image Rendering (Tone Mapping) 
% Written by David Alleysson and Laurence Meylan
% Copyright (C) 2007 Laboratory of Audiovisual Communications (LCAV), 
% Ecole Polytechnique Federale de Lausanne (EPFL), 
% CH-1015 Lausanne, Switzerland 
% 
% This program is free software; you can redistribute it and/or modify it 
% under the terms of the GNU General Public License as published by the 
% Free Software Foundation; either version 2 of the License, or (at your 
% option) any later version. This software is distributed in the hope that 
% it will be useful, but without any warranty; without even the implied 
% warranty of merchantability or fitness for a particular purpose. 
% See the GNU General Public License for more details 
% (enclosed in the file GPL). 
%
% Latest modifications: January 25, 2007, by Laurence Meylan

close all
clear all

global DISPLAY
DISPLAY = 0;

global FILTER_HORI
global FILTER_AMACRINE

FILTER_HORI = 3;
FILTER_AMACRINE = 1.5;


% Path definition
path(path,'../../../ImagesDatabase/hdrImages_sorted/HDRfromRaw/');
path(path,'../../../ImagesDatabase/hdrImages_sorted/TrueHDR/');
path(path,'../../../ImagesDatabase/hdrImages_sorted/');


path(path,'../../2006/JPG_images/');
path(path,'../../2006/RAW_images/oct10_pgm_MOSAIC/');


 file=dir('../../2006/JPG_images/*.jpg');
 
 for i=1:size(file,1)    
     mainHDR_CFA(file(i).name,'JPG')
 end
 
 file=dir('../../RAW_images/oct10_pgm_MOSAIC/*.pgm');
 
 for i=1:size(file,1)    
     mainHDR_CFA(file(i).name,'CRW')
 end

